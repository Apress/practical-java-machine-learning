/** Automatically generated file. DO NOT MODIFY */
package com.wickham.android.weka_android_3_8_1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}