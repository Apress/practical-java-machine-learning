package android.wickham.com.datavis;

/*
 * Copyright (C) 2018 Mark Wickham
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class MainActivity extends Activity {

    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = (WebView) findViewById(R.id.wb_webview);

        //Scroll bars should not be hidden
        webView.setScrollbarFadingEnabled(false);
        webView.setHorizontalScrollBarEnabled(true);
        webView.setVerticalScrollBarEnabled(true);
        webView.setFitsSystemWindows(true);

        //Enable JavaScript
        webView.getSettings().setJavaScriptEnabled(true);

        //Set the user agent
        webView.getSettings().setUserAgentString("AndroidWebView");

        //Clear the cache
        webView.clearCache(true);
        webView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        webView.setFadingEdgeLength(10);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);

        final Activity activity = this;
        final ProgressDialog progressDialog = new ProgressDialog(activity);
        //progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setProgressStyle(ProgressDialog.THEME_HOLO_LIGHT);
        progressDialog.setCancelable(true);

        webView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                progressDialog.setCanceledOnTouchOutside(true);
                progressDialog.setTitle("Loading visualization ...");
                progressDialog.setButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        webView.destroy();
                        finish();
                    } });
                progressDialog.show();
                progressDialog.setProgress(0);
                activity.setProgress(progress * 1000);
                progressDialog.incrementProgressBy(progress);
                if(progress == 100 && progressDialog.isShowing())
                    progressDialog.dismiss();
            }
        });
        
        // Load the URL of the HTML file containing the JavaScript D3 code
        webView.loadUrl("file:///android_asset/radial-dendo-csv.html");
    }
}
